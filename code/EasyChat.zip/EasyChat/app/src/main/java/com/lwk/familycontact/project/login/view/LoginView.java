package com.lwk.familycontact.project.login.view;

/**
 * TODO 登录界面View
 */
public interface LoginView
{
    void setLastLoginPhone(String phone);

    void setLastLoginPwd(String pwd);

    void showPhoneEmptyWarning();

    void showPwdEmptyWarning();

    void showPhoneErrorWarning();

    void showLoginDialog();

    void closeLoginDialog();

    void showLoginFailMsg(int msgId);

    void loginSuccess();
}
