package com.lwk.familycontact.project.common.image;

import android.graphics.Bitmap;

/**
 * TODO 位图下载监听
 */
public interface OnBitmapDownloadListener
{
    void onDownload(Bitmap bitmap);
}
