package com.lwk.familycontact.project.contact.view;

import com.lwk.familycontact.storage.db.user.UserBean;

import java.util.List;

/**
 * TODO 通讯录界面View
 */
public interface ContactView
{
    void autoRefresh();

    void refreshAllUsersSuccess(boolean isPrtRefresh, List<UserBean> allUserList);

    void refreshAllUsersFail(int errorMsgId);

    void refreshContactNum();

    void scrollToTop();

    void onAllFriendNotifyRead();

    void onFriendNotifyUnread(int num);
}
