package com.lwk.familycontact.project.call.presenter;

import android.os.Handler;

import com.lwk.familycontact.project.call.view.HxVoiceCallView;

/**
 * TODO 实时语音通话界面Presenter
 */
public class HxVoiceCallPresenter extends HxCallPresenter
{

    public HxVoiceCallPresenter(HxVoiceCallView viewImpl, Handler handler)
    {
        super(viewImpl, handler);
    }

}
