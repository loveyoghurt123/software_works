package com.lwk.familycontact.utils.event;

/**
 * TODO 常规通知标识
 */
public class ComNotifyConfig
{
    //刷新数据库里的通讯录数据
    public static final int REFRESH_CONTACT_IN_DB = 1;
    //刷新未读好友申请
    public static final int REFRESH_USER_INVITE = 2;
    //刷新未读消息
    public static final int REFRESH_UNREAD_MSG = 3;
}
