package com.lwk.familycontact.project.regist.view;

/**
 * TODO 注册界面View
 */
public interface RegistView
{
    void showPhoneEmptyWarning();

    void showPwdEmptyWarning();

    void showPhoneErrorWarning();

    void showRegistDialog();

    void closeRegistDialog();

    void showRegistFailMsg(int msgId);

    void registSuccess();
}
