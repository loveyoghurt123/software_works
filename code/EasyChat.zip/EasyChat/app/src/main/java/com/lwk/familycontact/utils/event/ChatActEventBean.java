package com.lwk.familycontact.utils.event;

/**
 * TODO 进入\离开聊天界面后发送的通知
 */
public class ChatActEventBean
{
    private boolean isEnterIn;

    private String conversatinoId;

    public ChatActEventBean()
    {
    }

    public ChatActEventBean(boolean isEnterIn, String conversatinoId)
    {
        this.isEnterIn = isEnterIn;
        this.conversatinoId = conversatinoId;
    }

    public String getConversatinoId()
    {
        return conversatinoId;
    }

    public void setConversatinoId(String conversatinoId)
    {
        this.conversatinoId = conversatinoId;
    }

    public boolean isEnterIn()
    {
        return isEnterIn;
    }

    public void setEnterIn(boolean enterIn)
    {
        isEnterIn = enterIn;
    }

    @Override
    public String toString()
    {
        return "ChatActEventBean{" +
                "isEnterIn=" + isEnterIn +
                ", conversatinoId='" + conversatinoId + '\'' +
                '}';
    }
}
