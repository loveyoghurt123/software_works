package com.lwk.familycontact.project.contact.view;

/**
 * TODO联系人资料详情view
 */
public interface UserDetailView
{
    void setDefaultHead();

    void setHead(String url);

    void setName(String name);

    void setPhone(String phone);

    void nonFriend();

    void showFirstEnterDialog();

    void updateLocalHeadFail();

    void updateNameFail();
}
