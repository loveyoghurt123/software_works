package com.lwk.familycontact.project.main.view;


/**
 * MainActivity的交互接口
 */
public interface MainView
{
    void onShowFirstBadgeNum(int num);

    void onHideFirstBadgeNum();

    void onShowMiddleBadgeNum(int num);

    void onHideMiddleBadgeNum();

}
