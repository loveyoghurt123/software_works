package com.lwk.familycontact.project.call.view;

/**
 * TODO 实时语音通话界面接口
 */
public interface HxVoiceCallView extends HxCallView
{

}
