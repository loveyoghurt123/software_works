package com.lwk.familycontact.project.contact.view;

/**
 * TODO 添加好友界面View
 */
public interface AddFriendView
{
    void phoneEmptyWarning();

    void phoneErrorWarning();

    void sendRequestSuccess();

    void sendRequestFail(int code,int errMsgId);
}
