package com.lwk.familycontact.project.contact.view;

/**
 * TODO 添加通讯录界面View
 */
public interface AddContactView
{
    void onUserExist();

    void onUserNotExist();

    void onUserSaved();
}
