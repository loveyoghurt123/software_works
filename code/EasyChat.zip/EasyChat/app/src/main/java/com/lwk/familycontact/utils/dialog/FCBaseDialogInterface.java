package com.lwk.familycontact.utils.dialog;

import android.view.View;

/**
 * TODO Dialog基类接口
 */
public interface FCBaseDialogInterface
{
    int getContentViewId();

    boolean isCancelable();

    boolean isCanceledOnTouchOutside();

    void initUI(View contentView);

    void show();

    void dismiss();

    boolean isDialogShowing();
}
