package com.lwk.familycontact.project.call.view;

/**
 * TODO 实时视频通话界面接口
 */
public interface HxVideoCallView extends HxCallView
{

}
