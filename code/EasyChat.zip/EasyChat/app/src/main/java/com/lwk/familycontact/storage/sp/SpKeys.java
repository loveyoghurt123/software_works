package com.lwk.familycontact.storage.sp;

/**
 * TODO Sp存储的键值
 */
public class SpKeys
{
    public static final String LAST_LOGIN_PHONE = "lastLoginPhone";
    public static final String LAST_LOGIN_PWD = "lastLoginPwd";
    public static final String DIAL_FEEDBACK = "dialFeedBack";
    public static final String VOICE_MSG_HANDFREE = "voiceMsgHandFree";
    public static final String NEW_MSG_NOTICE = "newMsgNotice";
    public static final String NEW_MSG_NOTICE_VOICE = "newMsgNoticeVoice";
    public static final String NEW_MSG_NOTICE_VIBRATE = "newMsgNoticeVibrate";
    public static final String CHAT_TEXT_INPUT_FIRST = "chatTextInputFirst";
    public static final String IS_FIRST_ENTER_CONTACT_DETAIL = "isFirstEnterDetail";
}
