package com.lwk.familycontact.project.notify.view;

import com.lwk.familycontact.storage.db.invite.InviteBean;

import java.util.List;

/**
 * TODO 新的好友通知界面接口
 */
public interface NewFriendView
{
    void onRefreshAllNotifySuccess(List<InviteBean> list);

    void showHandlingDialog();

    void closeHandingDialog();

    void showHandlingError(int status, int errResId);

    void onNotifyStatusChanged();

}
