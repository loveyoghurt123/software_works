package com.lwk.okhttp.cookie.store;

/**
 * Created by zhy on 16/3/10.
 */
public interface HasCookieStore
{
    OkCookieStore getCookieStore();
}
